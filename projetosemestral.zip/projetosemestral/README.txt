Integrantes do grupo:
- Lucas Fritsche
- Kauan Cornelsen Pereira

A página inicial é /pages/login.html

Dentro da pasta sql está o script de criação e inserção do banco de dados.